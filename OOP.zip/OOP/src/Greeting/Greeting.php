<?php

class Greeting{
    function  sayHello(){
        echo 'Hello Bitm';
    }
}